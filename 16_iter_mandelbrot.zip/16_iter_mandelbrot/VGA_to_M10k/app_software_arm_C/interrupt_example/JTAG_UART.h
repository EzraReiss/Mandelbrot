/* function prototypes */
void print_jtag(const char * str);
void put_jtag(char);
char get_jtag(void);
